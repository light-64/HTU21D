#include "stm32f10x.h"
#include "delay.h"
#include "usart1.h"
#include "i2c.h"
int main()
{
	float data,data2;
	delay_init();
	delay_ms(500);
	IIC_Init_HTU21D();
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	Usart1_Init(115200);              //����1���ܳ�ʼ����������115200

	delay_ms(500);

	while(1)
	{
		data = read_HTU21D(0xf3);
		data2 = read_HTU21D(0xf5);
		u1_printf("data:%.2f, %.2f\r\n",data,data2);
		delay_ms(500);
	}
}

